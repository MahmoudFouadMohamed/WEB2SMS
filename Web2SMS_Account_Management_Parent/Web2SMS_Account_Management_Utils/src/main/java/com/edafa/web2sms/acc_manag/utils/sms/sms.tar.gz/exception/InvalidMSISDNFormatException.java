package com.edafa.web2sms.utils.sms.exception;

public class InvalidMSISDNFormatException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6443534238999501074L;

}
