package com.edafa.web2sms.utils.sms;

public enum ReceiverType {
	NATIONAL, INTERNATIONAL;
}
