package com.edafa.web2sms.utils.sms;

public enum MsisdnFormat {

	INTER, INTER_KEY, INTER_PLUS, INTER_KEY_CC_LOCAL, INTER_PLUS_CC_LOCAL, INTER_CC_LOCAL, NATIONAL_KEY, NATIONAL;

}
