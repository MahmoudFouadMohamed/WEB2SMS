package com.edafa.web2sms.utils.sms;

public enum SenderType {
	ALPHANUMERIC, SHORT_CODE, NATIONAL, INTERNATIONAL, UNKNOWN;
}
